const request = require('request')

class RequestService {
  constructor (service) {
    this.service = service
  }

  send (hook) {
    return this.service.sendHook(hook).promise()
  }
}

module.exports = new RequestService(request)
